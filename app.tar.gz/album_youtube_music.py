import flet as ft
import asyncio
import base64
import urllib.parse
from PIL import Image
from collections import Counter
from transformers import pipeline

# 1. AI 분석기 클래스 (A형: 태그 기반 통합 분석)
class AIAlbumAnalyzer:
    def __init__(self):
        # 가벼운 이미지 분류 모델 사용 (최초 실행 시 다운로드)
        self.classifier = pipeline("image-classification", model="google/vit-base-patch16-224")

    def get_tags(self, image_paths):
        all_tags = []
        for path in image_paths:
            try:
                img = Image.open(path)
                results = self.classifier(img)
                # 가장 확률이 높은 태그 1개만 추출
                all_tags.append(results[0]['label'])
            except:
                continue
        # 가장 빈도가 높은 상위 3개 키워드 반환
        return [tag for tag, count in Counter(all_tags).most_common(3)]

async def main(page: ft.Page):
    page.title = "AI 감성 앨범 - 통합 에디션"
    page.window_width = 1300
    page.window_height = 900
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 20
    
    # 상태 관리 변수
    images_list = []
    current_index = 0
    is_album_running = False
    analyzer = AIAlbumAnalyzer()
    album_task = None

    # --- [UI 컴포넌트] ---
    img_display = ft.Image(
        src="https://via.placeholder.com/800x600?text=Upload+Your+Photos",
        width=700, height=450, fit=ft.ImageFit.CONTAIN, border_radius=15,
    )
    
    index_text = ft.Text("0 / 0", size=14, weight="bold", color=ft.Colors.BLUE_GREY_400)
    ai_result_text = ft.Text("앨범 분석 전입니다.", color=ft.Colors.BLUE_700, weight="bold")
    
    # [핵심] 앱 내장 유튜브 뮤직 웹뷰
    music_webview = ft.WebView(
        "https://music.youtube.com",
        expand=True,
    )

    # --- [제어 로직] ---
    def update_ui():
        index_text.value = f"{current_index + 1} / {len(images_list)}" if images_list else "0 / 0"
        page.update()

    async def play_slideshow():
        nonlocal current_index
        while is_album_running and images_list:
            current_index = (current_index + 1) % len(images_list)
            try:
                with open(images_list[current_index], "rb") as f:
                    img_display.src_base64 = base64.b64encode(f.read()).decode('utf-8')
                update_ui()
            except: pass
            await asyncio.sleep(speed_slider.value)

    async def start_album(e):
        nonlocal is_album_running, album_task
        if not images_list: return
        is_album_running = True
        start_btn.visible, stop_btn.visible = False, True
        page.update()
        album_task = asyncio.create_task(play_slideshow())

    async def stop_album(e):
        nonlocal is_album_running
        is_album_running = False
        if album_task: album_task.cancel()
        start_btn.visible, stop_btn.visible = True, False
        page.update()

    async def analyze_and_play(e):
        if not images_list: return
        ai_result_text.value = "AI 분석 중... (모든 사진의 분위기를 수집하고 있습니다)"
        analyze_btn.disabled = True
        page.update()

        loop = asyncio.get_event_loop()
        top_tags = await loop.run_in_executor(None, analyzer.get_tags, images_list)
        
        # 유튜브 뮤직 검색어 생성 및 웹뷰 업데이트
        search_query = f"{' '.join(top_tags)} music playlist"
        encoded_query = urllib.parse.quote(search_query)
        music_webview.url = f"https://music.youtube.com/search?q={encoded_query}"
        
        ai_result_text.value = f"분석 완료! 테마: {' #'.join(top_tags)}"
        analyze_btn.disabled = False
        page.update()

    # --- [이벤트 핸들러] ---
    def on_files(e: ft.FilePickerResultEvent):
        if e.files:
            images_list.clear()
            for f in e.files: images_list.append(f.path)
            with open(images_list[0], "rb") as f:
                img_display.src_base_64 = base64.b64encode(f.read()).decode('utf-8')
            update_ui()
            start_btn.disabled = analyze_btn.disabled = False
            page.update()

    picker = ft.FilePicker(on_result=on_files)
    page.overlay.append(picker)

    # --- [UI 레이아웃 요소] ---
    speed_slider = ft.Slider(min=1, max=10, value=3, label="{value}초")
    start_btn = ft.ElevatedButton("Start", icon=ft.Icons.PLAY_ARROW, on_click=start_album, bgcolor="blue", color="white", disabled=True)
    stop_btn = ft.ElevatedButton("Stop", icon=ft.Icons.STOP, on_click=stop_album, bgcolor="orange", color="white", visible=False)
    analyze_btn = ft.ElevatedButton("AI 테마 분석 & 음악 매칭", icon=ft.Icons.AUTO_AWESOME, on_click=analyze_and_play, disabled=True)

    # --- [전체 화면 구성] ---
    page.add(
        ft.Row([
            # 왼쪽 영역: 사진 및 컨트롤
            ft.Column([
                ft.Text("AI Emotional Album", size=30, weight="bold"),
                ft.Stack([
                    ft.Container(img_display, padding=10, border_radius=20, bgcolor="white", shadow=ft.BoxShadow(blur_radius=15, color="black12")),
                    ft.Container(index_text, top=25, right=25, bgcolor="white70", padding=5, border_radius=5)
                ]),
                ft.Card(
                    content=ft.Container(
                        padding=20,
                        content=ft.Column([
                            ft.Row([ft.Text("넘김 속도"), speed_slider], alignment="center"),
                            ft.Row([start_btn, stop_btn, analyze_btn], alignment="center", spacing=10),
                            ai_result_text
                        ], horizontal_alignment="center")
                    )
                ),
                ft.ElevatedButton("사진 추가하기", icon=ft.Icons.ADD_A_PHOTO, on_click=lambda _: picker.pick_files(allow_multiple=True))
            ], expand=6, horizontal_alignment="center"),
            
            ft.VerticalDivider(width=1),
            
            # 오른쪽 영역: 내장 유튜브 뮤직
            ft.Column([
                ft.Text("YouTube Music Search", size=20, weight="bold"),
                ft.Container(content=music_webview, border=ft.border.all(1, ft.Colors.OUTLINE), border_radius=10, expand=True)
            ], expand=4)
        ], expand=True)
    )

ft.app(target=main)