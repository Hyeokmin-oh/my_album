import flet as ft
import asyncio
import base64
import os
import random

async def main(page: ft.Page):
    page.title = "감성 사진첩 Web v1.3"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 0
    page.bgcolor = ft.Colors.BLUE_GREY_50
    
    # 상태 관리
    images_list = []
    current_index = 0
    is_album_running = False
    album_task = None
    current_mood = "Bright"

    # --- [오디오 엔진] ---
    audio_player = ft.Audio(src="about:blank", autoplay=False, volume=0.5)
    page.overlay.append(audio_player)

    # --- [UI 컴포넌트 선언] ---
    img_display = ft.Image(
        src="https://via.placeholder.com/800x600?text=Select+Photos+to+Start",
        width=800, height=550, fit=ft.ImageFit.CONTAIN, border_radius=15
    )

    image_container = ft.AnimatedSwitcher(
        img_display,
        transition=ft.AnimatedSwitcherTransition.FADE,
        duration=800,
        switch_in_curve=ft.AnimationCurve.EASE_IN_OUT,
    )
    
    index_text = ft.Text("0 / 0", size=14, weight="bold", color="white")
    speed_val_text = ft.Text("3초", color="white", size=12)
    volume_val_text = ft.Text("5", size=14, weight="bold")
    music_time_text = ft.Text("00:00 / 00:00", size=12, color=ft.Colors.BLUE_GREY_400)
    status_text = ft.Text("준비됨", size=12, italic=True, text_align="center", width=250)

    # --- [사진 제어 로직] ---
    def update_image():
        if images_list:
            with open(images_list[current_index], "rb") as f:
                img_display.src_base64 = base64.b64encode(f.read()).decode('utf-8')
            index_text.value = f"{current_index + 1} / {len(images_list)}"
            image_container.update()
            page.update()

    async def run_slideshow():
        nonlocal current_index
        while is_album_running and images_list:
            current_index = (current_index + 1) % len(images_list)
            update_image()
            await asyncio.sleep(speed_slider.value)

    def next_image(e):
        nonlocal current_index
        if images_list:
            current_index = (current_index + 1) % len(images_list)
            update_image()

    def prev_image(e):
        nonlocal current_index
        if images_list:
            current_index = (current_index - 1) % len(images_list)
            update_image()

    def reset_album(e):
        nonlocal current_index, is_album_running
        handle_stop(None)
        current_index = 0
        update_image()

    # --- [음악 제어 로직] ---
    def play_mood_music(mood_name):
        nonlocal current_mood
        current_mood = mood_name
        folder_path = os.path.join("assets", mood_name)
        if os.path.exists(folder_path):
            songs = [f for f in os.listdir(folder_path) if f.lower().endswith(".mp3")]
            if songs:
                chosen = random.choice(songs)
                audio_player.src = f"/{mood_name}/{chosen}"
                audio_player.update()
                audio_player.play()
                status_text.value = f"🎵 {chosen}"
        page.update()

    audio_player.on_state_changed = lambda e: play_mood_music(current_mood) if e.data == "completed" else None
    
    def on_position_changed(e):
        pos, dur = int(e.position/1000), int(audio_player.get_duration()/1000) if audio_player.get_duration() else 0
        music_time_text.value = f"{pos//60:02}:{pos%60:02} / {dur//60:02}:{dur%60:02}"
        page.update()
    audio_player.on_position_changed = on_position_changed

    # --- [핸들러 함수] ---
    async def handle_start(e):
        nonlocal is_album_running, album_task
        if not images_list: return
        is_album_running = True
        start_btn.visible, stop_btn.visible = False, True
        page.update()
        album_task = asyncio.create_task(run_slideshow())

    def handle_stop(e):
        nonlocal is_album_running
        is_album_running = False
        if album_task: album_task.cancel()
        start_btn.visible, stop_btn.visible = True, False
        page.update()

    def on_file_result(e: ft.FilePickerResultEvent):
        if e.files:
            images_list.clear()
            for f in e.files: images_list.append(f.path)
            current_index = 0
            update_image()
            start_btn.disabled = False
            page.update()

    picker = ft.FilePicker(on_result=on_file_result)
    page.overlay.append(picker)

    # --- [음악 오버레이 패널] ---
    music_panel = ft.Container(
        content=ft.Column([
            ft.Row([ft.Text("Music Player", size=20, weight="bold"), ft.IconButton(ft.Icons.CLOSE, on_click=lambda _: hide_panel())], alignment="spaceBetween"),
            ft.Divider(),
            status_text, music_time_text,
            ft.Row([ft.ElevatedButton("☀️ Bright", on_click=lambda _: play_mood_music("Bright"), expand=True),
                    ft.ElevatedButton("🌿 Calm", on_click=lambda _: play_mood_music("Calm"), expand=True),
                    ft.ElevatedButton("⚡ Energetic", on_click=lambda _: play_mood_music("Energetic"), expand=True)], spacing=5),
            ft.Row([ft.IconButton(ft.Icons.SKIP_PREVIOUS, on_click=lambda _: play_mood_music(current_mood)),
                    ft.IconButton(ft.Icons.PLAY_ARROW, icon_size=40, on_click=lambda _: audio_player.resume()),
                    ft.IconButton(ft.Icons.PAUSE, icon_size=40, on_click=lambda _: audio_player.pause()),
                    ft.IconButton(ft.Icons.SKIP_NEXT, on_click=lambda _: play_mood_music(current_mood))], alignment="center"),
            ft.Row([ft.Icon(ft.Icons.VOLUME_UP, size=20), 
                    volume_slider := ft.Slider(min=0, max=1, value=0.5, divisions=10, width=180, on_change=lambda e: (setattr(volume_val_text, "value", str(int(e.control.value*10))), setattr(audio_player, "volume", e.control.value), audio_player.update(), page.update())),
                    volume_val_text], alignment="center"),
        ], horizontal_alignment="center", spacing=15),
        bgcolor=ft.Colors.with_opacity(0.98, "white"), width=350, height=480, border_radius=20, padding=20,
        shadow=ft.BoxShadow(blur_radius=20, color="black26"), right=-350, top=80,
        animate=ft.Animation(500, ft.AnimationCurve.DECELERATE), 
    )

    def show_panel(e): music_panel.right = 20; music_panel.update()
    def hide_panel(): music_panel.right = -350; music_panel.update()

    # --- [버튼 및 슬라이더 정의] ---
    start_btn = ft.IconButton(ft.Icons.PLAY_CIRCLE_FILL, icon_size=45, icon_color="white", on_click=handle_start, disabled=True, tooltip="슬라이드 시작")
    stop_btn = ft.IconButton(ft.Icons.STOP_CIRCLE, icon_size=45, icon_color="red_400", on_click=handle_stop, visible=False, tooltip="정지")
    speed_slider = ft.Slider(min=1, max=10, value=3, divisions=9, width=150, on_change=lambda e: (setattr(speed_val_text, "value", f"{int(e.control.value)}초"), page.update()))

    # --- [메인 레이아웃] ---
    main_stack = ft.Stack([
        ft.Container(
            content=image_container, 
            margin=ft.margin.only(top=40, bottom=140, left=40, right=40),
            alignment=ft.alignment.center,
            bgcolor=ft.Colors.WHITE,
            border_radius=20,
            shadow=ft.BoxShadow(blur_radius=30, color="black12")
        ),
        ft.Container(index_text, top=60, left=60, bgcolor="black54", padding=10, border_radius=10),
        
        # 하단 통합 컨트롤 바
        ft.Container(
            content=ft.Row([
                ft.Row([
                    ft.IconButton(ft.Icons.SKIP_PREVIOUS, icon_color="white", on_click=prev_image, tooltip="이전 사진"),
                    start_btn, stop_btn,
                    ft.IconButton(ft.Icons.SKIP_NEXT, icon_color="white", on_click=next_image, tooltip="다음 사진"),
                    ft.IconButton(ft.Icons.REPLAY, icon_color="white", on_click=reset_album, tooltip="처음부터"),
                ], spacing=5),
                ft.VerticalDivider(color="white24"),
                ft.ElevatedButton("사진 추가", icon=ft.Icons.ADD_A_PHOTO, on_click=lambda _: picker.pick_files(allow_multiple=True)),
                ft.Column([ft.Row([ft.Text("속도", color="white", size=10), speed_val_text], spacing=5), speed_slider], alignment="center", spacing=0),
                ft.IconButton(ft.Icons.MUSIC_NOTE, on_click=show_panel, icon_color="white", icon_size=35),
            ], alignment="center", spacing=20),
            bottom=30, left=30, right=30, height=100, bgcolor="black87", border_radius=50, padding=ft.padding.only(left=20, right=20)
        ),
        music_panel 
    ], expand=True)

    page.add(main_stack)

if __name__ == "__main__":
    ft.app(target=main, assets_dir="assets")