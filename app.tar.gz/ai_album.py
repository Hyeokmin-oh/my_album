import flet as ft
import asyncio
import base64
import os
import random
from PIL import Image
from collections import Counter
from transformers import pipeline
from googletrans import Translator

class AIAlbumAnalyzer:
    def __init__(self):
        # AI 모델 로드
        self.classifier = pipeline("image-classification", model="google/vit-base-patch16-224")
        self.translator = Translator()
        
        # 1. [강력한 한글 매핑] AI가 자주 내놓는 단어들을 미리 한글화
        self.ko_map = {
            "valley": "계곡", "forest": "숲", "ocean": "바다", "beach": "해변", 
            "sky": "하늘", "person": "사람", "street": "거리", "mountain": "산",
            "dog": "강아지", "cat": "고양이", "field": "들판", "city": "도시",
            "seashore": "해안가", "lakeside": "호숫가", "park": "공원", "tree": "나무"
        }
        
        # 2. 분위기 분류 기준
        self.mood_keywords = {
            "Calm": ["계곡", "숲", "산", "자연", "나무", "조용한", "차분한", "밤", "호수", "호숫가"],
            "Bright": ["바다", "해변", "하늘", "강아지", "꽃", "밝은", "햇살", "들판", "여름", "해안가"],
            "Energetic": ["사람", "거리", "도시", "자동차", "축제", "운동", "활동적인", "클럽", "공원"]
        }

    def get_tags(self, image_paths):
        all_raw_tags = []
        for path in image_paths:
            try:
                img = Image.open(path).convert("RGB")
                results = self.classifier(img)
                all_raw_tags.append(results[0]['label'].lower().split(',')[0]) # 첫 번째 단어만 추출
            except: continue
        
        top_raw = [tag for tag, count in Counter(all_raw_tags).most_common(5)]
        
        processed = []
        for t in top_raw:
            # 매핑 사전에 있으면 바로 쓰고, 없으면 번역기 사용
            ko_text = self.ko_map.get(t)
            if not ko_text:
                try:
                    ko_text = self.translator.translate(t, src='en', dest='ko').text
                except:
                    ko_text = t
            
            # 분위기 유추
            mood = "Bright"
            for m, keywords in self.mood_keywords.items():
                if any(kw in ko_text for kw in keywords):
                    mood = m
                    break
            processed.append({"ko": ko_text, "mood": mood})
        return processed

async def main(page: ft.Page):
    page.title = "AI 감성 앨범 - 스마트 UX"
    page.window_width = 800
    page.window_height = 950
    page.theme_mode = ft.ThemeMode.LIGHT
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.ADAPTIVE
    
    # 데이터 관리
    images_list = []
    current_index = 0
    is_album_running = False
    analyzer = AIAlbumAnalyzer()
    album_task = None

    # --- [오디오 엔진] ---
    audio_player = ft.Audio(src="", autoplay=False, volume=0.5)
    page.overlay.append(audio_player)

    img_display = ft.Image(
        src="https://via.placeholder.com/600x400?text=AI+Album",
        width=600, height=400, fit=ft.ImageFit.CONTAIN, border_radius=20
    )
    
    index_text = ft.Text("0 / 0", size=14, weight="bold", color=ft.Colors.BLUE_GREY_400)
    ai_status = ft.Text("사진을 추가하고 감성 분석을 눌러주세요.", size=15)
    tag_container = ft.Row(wrap=True, spacing=10, alignment=ft.MainAxisAlignment.CENTER)
    speed_slider = ft.Slider(min=1, max=10, value=3, label="{value}초")
    volume_slider = ft.Slider(min=0, max=1, value=0.5)

    # [디자인] 음악 컨트롤 섹션
    music_control_panel = ft.Container(
        content=ft.Column([
            ft.Divider(),
            ft.Text("🎵 AI 추천 테마 & 음악", size=20, weight="bold"),
            tag_container,
            ft.Row([ft.Text("음악 볼륨"), volume_slider], alignment="center"),
            ft.ElevatedButton("다른 곡 재생", icon=ft.Icons.REFRESH, on_click=lambda e: play_logic())
        ], horizontal_alignment="center"),
        height=0,
        opacity=0,
        animate=ft.Animation(500, ft.AnimationCurve.DECELERATE),
        clip_behavior=ft.ClipBehavior.HARD_EDGE
    )

    # --- [재생 로직] ---
    def play_logic():
        selected_moods = [cb.data for cb in tag_container.controls if cb.value]
        if not selected_moods: return

        target_folder = Counter(selected_moods).most_common(1)[0][0]
        folder_path = os.path.join("assets", target_folder)

        if os.path.exists(folder_path):
            songs = [f for f in os.listdir(folder_path) if f.endswith(".mp3")]
            if songs:
                chosen = random.choice(songs)
                audio_player.src = f"/{target_folder}/{chosen}"
                audio_player.update()
                audio_player.play()
                ai_status.value = f"테마 [{target_folder}] 자동 매칭 완료! 음악을 재생합니다."
                page.update()

    async def on_analyze_click(e):
        if not images_list: return
        ai_status.value = "AI가 감성을 분석하고 번역 중입니다..."
        analyze_btn.disabled = True
        page.update()

        loop = asyncio.get_event_loop()
        tags_info = await loop.run_in_executor(None, analyzer.get_tags, images_list)
        
        tag_container.controls.clear()
        for info in tags_info:
            tag_container.controls.append(ft.Checkbox(label=info["ko"], value=True, data=info["mood"]))
        
        # 패널 펼치기
        music_control_panel.height = 250
        music_control_panel.opacity = 1
        
        play_logic() # 자동 재생
        
        analyze_btn.disabled = False
        page.update()

    # --- [슬라이드쇼] ---
    async def play_slideshow():
        nonlocal current_index
        while is_album_running and images_list:
            current_index = (current_index + 1) % len(images_list)
            with open(images_list[current_index], "rb") as f:
                img_display.src_base64 = base64.b64encode(f.read()).decode('utf-8')
            index_text.value = f"{current_index + 1} / {len(images_list)}"
            page.update()
            await asyncio.sleep(speed_slider.value)

    async def start_album(e):
        nonlocal is_album_running, album_task
        if not images_list: return
        is_album_running = True
        start_btn.visible, stop_btn.visible = False, True
        page.update()
        album_task = asyncio.create_task(play_slideshow())

    def stop_album(e):
        nonlocal is_album_running
        is_album_running = False
        if album_task: album_task.cancel()
        audio_player.pause()
        start_btn.visible, stop_btn.visible = True, False
        page.update()

    # --- [파일 선택] ---
    def on_file_result(e: ft.FilePickerResultEvent):
        if e.files:
            images_list.clear()
            for f in e.files: images_list.append(f.path)
            with open(images_list[0], "rb") as f:
                img_display.src_base64 = base64.b64encode(f.read()).decode('utf-8')
            index_text.value = f"1 / {len(images_list)}"
            start_btn.disabled = analyze_btn.disabled = False
            page.update()

    picker = ft.FilePicker(on_result=on_file_result)
    page.overlay.append(picker)

    # --- [버튼 정의] ---
    start_btn = ft.ElevatedButton("앨범 시작", icon=ft.Icons.PLAY_ARROW, on_click=start_album, disabled=True)
    stop_btn = ft.ElevatedButton("정지", icon=ft.Icons.STOP, on_click=stop_album, visible=False)
    
    # [에러 수정] color 대신 내부 텍스트 색상 활용
    analyze_btn = ft.FloatingActionButton(
        content=ft.Row([ft.Icon(ft.Icons.AUTO_AWESOME), ft.Text("감성 분석", color="white")], alignment="center"),
        width=150, 
        on_click=on_analyze_click, 
        disabled=True, 
        bgcolor=ft.Colors.BLUE_500
    )

    # --- [레이아웃 구성] ---
    page.add(
        ft.Container(
            content=ft.Column([
                ft.Text("AI 감성 앨범", size=32, weight="bold", color=ft.Colors.BLUE_800),
                ft.Stack([
                    ft.Container(img_display, border_radius=20, shadow=ft.BoxShadow(blur_radius=20, color="black12"), bgcolor="white"),
                    ft.Container(index_text, top=20, right=20, bgcolor="white70", padding=8, border_radius=8)
                ]),
                ft.Row([ft.Text("넘김 속도"), speed_slider], alignment="center"),
                ft.Row([
                    start_btn, 
                    stop_btn, 
                    ft.ElevatedButton("사진 추가", icon=ft.Icons.ADD_A_PHOTO, on_click=lambda _: picker.pick_files(allow_multiple=True))
                ], alignment="center", spacing=10),
                ai_status,
                music_control_panel,
                ft.Container(height=20),
                analyze_btn
            ], horizontal_alignment="center"),
            padding=30
        )
    )

    volume_slider.on_change = lambda e: (setattr(audio_player, "volume", e.control.value), audio_player.update())

ft.app(target=main, assets_dir="assets")