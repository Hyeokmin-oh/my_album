import flet as ft
import asyncio
import base64
import os
import random

async def main(page: ft.Page):
    page.title = "감성 사진첩 - 프로 플레이어 에디션"
    page.window_width = 850
    page.window_height = 900
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 0
    
    # 상태 관리
    images_list = []
    current_index = 0
    is_album_running = False
    album_task = None
    current_mood = "Bright"

    # --- [오디오 엔진 & 초기 배경음] ---
    initial_bgm = ""
    try:
        if os.path.exists(f"assets/{current_mood}"):
            bgm_files = [f for f in os.listdir(f"assets/{current_mood}") if f.lower().endswith(".mp3")]
            if bgm_files:
                initial_bgm = f"/{current_mood}/{bgm_files[0]}"
    except: pass

    audio_player = ft.Audio(src=initial_bgm, autoplay=True, volume=0.5)
    page.overlay.append(audio_player)

    # --- [UI 컴포넌트] ---
    img_display = ft.Image(
        src="https://via.placeholder.com/800x600?text=Select+Photos",
        width=750, height=500, fit=ft.ImageFit.CONTAIN, border_radius=15
    )

    image_container = ft.AnimatedSwitcher(
        img_display,
        transition=ft.AnimatedSwitcherTransition.FADE,
        duration=1000,
        switch_in_curve=ft.AnimationCurve.EASE_IN_OUT,
    )
    
    # 수치 표시 텍스트
    index_text = ft.Text("0 / 0", size=14, weight="bold", color="white")
    speed_value_text = ft.Text("3초", color="white", size=12)
    volume_value_text = ft.Text("5", size=14, weight="bold")
    music_time_text = ft.Text("00:00 / 00:00", size=12, color=ft.Colors.BLUE_GREY_400)
    status_text = ft.Text("준비됨", size=12, italic=True, overflow=ft.TextOverflow.ELLIPSIS, width=200, text_align="center")

    # --- [제어 로직] ---
    def update_speed_text(e):
        speed_value_text.value = f"{int(e.control.value)}초"
        page.update()

    def update_volume(e):
        val = e.control.value
        audio_player.volume = val
        volume_value_text.value = f"{int(val * 10)}"
        audio_player.update()
        page.update()

    def play_mood_music(mood_name):
        nonlocal current_mood
        current_mood = mood_name
        folder_path = os.path.join("assets", mood_name)
        if os.path.exists(folder_path):
            songs = [f for f in os.listdir(folder_path) if f.lower().endswith(".mp3")]
            if songs:
                chosen = random.choice(songs)
                audio_player.src = f"/{mood_name}/{chosen}"
                audio_player.update()
                audio_player.play()
                status_text.value = f"🎵 {chosen}"
        page.update()

    # 오디오 상태 모니터링 (연속 재생 및 시간 표시)
    def on_audio_state_change(e):
        # 노래가 끝나면(completed) 다음 랜덤 곡 재생
        if e.data == "completed":
            play_mood_music(current_mood)

    def on_audio_position_changed(e):
        pos = int(e.position / 1000)
        dur = int(audio_player.get_duration() / 1000) if audio_player.get_duration() else 0
        music_time_text.value = f"{pos//60:02}:{pos%60:02} / {dur//60:02}:{dur%60:02}"
        page.update()

    audio_player.on_state_changed = on_audio_state_change
    audio_player.on_position_changed = on_audio_position_changed

    # --- [음악 패널 오버레이] ---
    music_panel = ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Text("Music Player", size=20, weight="bold"),
                ft.IconButton(ft.Icons.CLOSE, on_click=lambda _: hide_panel())
            ], alignment="spaceBetween"),
            ft.Divider(),
            status_text,
            music_time_text,
            ft.Row([
                ft.ElevatedButton("☀️ Bright", on_click=lambda _: play_mood_music("Bright"), expand=True),
                ft.ElevatedButton("🌿 Calm", on_click=lambda _: play_mood_music("Calm"), expand=True),
                ft.ElevatedButton("⚡ Energetic", on_click=lambda _: play_mood_music("Energetic"), expand=True),
            ], spacing=3),
            ft.Row([
                ft.IconButton(ft.Icons.SKIP_PREVIOUS, on_click=lambda _: play_mood_music(current_mood)),
                ft.IconButton(ft.Icons.PLAY_ARROW, icon_size=40, on_click=lambda _: audio_player.resume()),
                ft.IconButton(ft.Icons.PAUSE, icon_size=40, on_click=lambda _: audio_player.pause()), # 아이콘 이름 수정
                ft.IconButton(ft.Icons.SKIP_NEXT, on_click=lambda _: play_mood_music(current_mood)),
            ], alignment="center"),
            ft.Row([
                ft.Icon(ft.Icons.VOLUME_UP, size=20),
                volume_slider := ft.Slider(min=0, max=1, value=0.5, divisions=10, on_change=update_volume, width=180),
                volume_value_text
            ], alignment="center"),
        ], horizontal_alignment="center", spacing=15),
        bgcolor=ft.Colors.with_opacity(0.80, "white"),
        width=350, height=480, border_radius=20, padding=20,
        shadow=ft.BoxShadow(blur_radius=20, color="black26"),
        right=-350, top=80,
        animate=ft.Animation(500, ft.AnimationCurve.DECELERATE), 
    )

    def show_panel(e):
        music_panel.right = 20
        music_panel.update()

    def hide_panel():
        music_panel.right = -350
        music_panel.update()

    # --- [사진 슬라이드 및 기타 로직] ---
    async def play_slideshow():
        nonlocal current_index
        while is_album_running and images_list:
            current_index = (current_index + 1) % len(images_list)
            with open(images_list[current_index], "rb") as f:
                img_display.src_base64 = base64.b64encode(f.read()).decode('utf-8')
            index_text.value = f"{current_index + 1} / {len(images_list)}"
            image_container.update() 
            page.update()
            await asyncio.sleep(speed_slider.value)

    def on_file_result(e: ft.FilePickerResultEvent):
        if e.files:
            images_list.clear()
            for f in e.files: images_list.append(f.path)
            with open(images_list[0], "rb") as f:
                img_display.src_base64 = base64.b64encode(f.read()).decode('utf-8')
            index_text.value = f"1 / {len(images_list)}"
            start_btn.disabled = False
            image_container.update()
            page.update()

    picker = ft.FilePicker(on_result=on_file_result)
    page.overlay.append(picker)

    async def start_album(e):
        nonlocal is_album_running, album_task
        is_album_running = True
        start_btn.visible, stop_btn.visible = False, True
        page.update()
        album_task = asyncio.create_task(play_slideshow())

    def stop_album(e):
        nonlocal is_album_running
        is_album_running = False
        if album_task: album_task.cancel()
        start_btn.visible, stop_btn.visible = True, False
        page.update()

    # --- [전체 레이아웃] ---
    speed_slider = ft.Slider(min=1, max=10, value=3, divisions=9, on_change=update_speed_text, width=150)
    start_btn = ft.ElevatedButton("시작", icon=ft.Icons.PLAY_ARROW, on_click=start_album, disabled=True)
    stop_btn = ft.ElevatedButton("정지", icon=ft.Icons.STOP, on_click=stop_album, visible=False)
    add_photo_btn = ft.ElevatedButton("사진 추가", icon=ft.Icons.ADD_A_PHOTO, on_click=lambda _: picker.pick_files(allow_multiple=True))

    main_stack = ft.Stack([
        ft.Container(
            content=image_container, 
            margin=ft.margin.all(40),
            alignment=ft.alignment.center,
            bgcolor=ft.Colors.WHITE,
            border_radius=20,
            shadow=ft.BoxShadow(blur_radius=30, color="black12")
        ),
        ft.Container(index_text, top=60, left=60, bgcolor="black54", padding=10, border_radius=10),
        ft.Container(
            content=ft.Row([
                start_btn, stop_btn,
                add_photo_btn,
                ft.Column([
                    ft.Row([ft.Text("속도", color="white", size=10), speed_value_text], spacing=5),
                    speed_slider
                ], alignment="center", spacing=0),
                ft.IconButton(ft.Icons.MUSIC_NOTE, on_click=show_panel, icon_color="white", icon_size=30),
            ], alignment="center", spacing=15),
            bottom=40, left=40, right=40, height=80, bgcolor="black54", border_radius=40
        ),
        music_panel 
    ], expand=True)

    page.add(main_stack)

ft.app(target=main, assets_dir="assets")